//
//  main.swift
//  9*9
//
//  Created by apple on 2016/11/21.
//  Copyright © 2016年 apple. All rights reserved.
//

import Foundation

func multiplicationTable(_ multiplier:Int){
    
    for row in 1...multiplier {
        for column in 1...row {
            print("\(row)*\(column) = \(row * column)",terminator:"\t")
        }
        print("\n")
    }
    
}
multiplicationTable(9)

