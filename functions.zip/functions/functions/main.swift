//
//  main.swift
//  functions
//
//  Created by apple on 16/11/10.
//  Copyright (c) 2016年 apple. All rights reserved.
//

import Foundation

//func print0_100(){
//    for i in 0..<100{
//        print(i)
//    }
//}
//print0_100()
//
//func print0_100(){
//    for i in 0..<100{
//        print(i)
//    }
//}
//print0_100()

//func add(a:Int,b:Int){
//    print(a+b)
//}
//add(a:2,b:3)


func add(a:Int,b:Int)->Int{
 

return a+b
}
print(add(a:2,b:3))



