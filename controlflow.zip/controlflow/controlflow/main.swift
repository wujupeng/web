//
//  main.swift
//  controlflow
//
//  Created by apple on 16/11/9.
//  Copyright (c) 2016年 apple. All rights reserved.
//

import Foundation

//let score = 106
//if score > 101{
 //   print("Nothing")
//}
//else if score >= 90{
  //  print("youxiu")
//}else if score >= 80{
  //  print("lianghao")
//}else if score >= 70{
 //   print("keyi")
//}else if score >= 60{
//    print("jige")
//}else {
  //  print("No No No")
//}

let score = 80
switch(score/10){
case 9:
    print("good")
case 8:
    print("ok")
case 7:
    print("hao")
case 6:
    print("jige")
default:
    print("No No No")
    
}