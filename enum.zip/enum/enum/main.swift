//
//  main.swift
//  enum
//
//  Created by apple on 2016/11/17.
//  Copyright © 2016年 apple. All rights reserved.
//

import Foundation

//print("Hello, World!")
//var Up = 1
//    Right = 2
//    Down = 3
//    Left = 4
//enum Direction{
//    case Up
//    case Right
//    case Down
//    case Left
//}
//print(Direction.Left.hashValue)



//enum Direction:String{
//    case Up = "up"
//    case Right = "Right"
//    case Down = "Down"
//    case Left = "Left"
//    
//    func getRotation()->Int{
//        switch self{
//        case.Up:
//            return 0
//        case.Right:
//            return 90
//        case.Down:
//            return 180
//        case.Left:
//            return 270
//        }
//    }
//}
//print(Direction.Left.getRotation())

//struct Student{
//    var name:String
//    var age:Int
//    
//}
//var s = Student(name:"zhangsan",age:26)
//print(s.age)

//
//struct Student{
//    var name:String
//    var age:Int
//    init(name:String="wujupeng",age:Int=2){
//        self.name = name
//        self.age = age
//        print("Crate a student")
//        
//    }
//    func toString()->String{
//        return "age:\(self.age),name:\(self.name)"
//    }
//    
//    
//}
//var s = Student(name: "zhangsan", age: 26)
//print(s.toString())


struct Student{
    var name:String
    var age:Int
    init(name:String="wujupeng",age:Int=27){
        self.name = name
        self.age = age
        print("Crate a student")
        
    }
    func toString()->String{
        return "age:\(self.age),name:\(self.name)"
    }
    
    
}
var s = Student()
print(s.toString())













